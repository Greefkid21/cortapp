import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Lock, Mail, Wand2 } from 'lucide-react';

export function Login() {
  const [mode, setMode] = useState<'password' | 'magic-link' | 'signup' | 'forgot-password'>('password');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const { login, signup, loginWithMagicLink, resetPassword } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (mode === 'signup') {
      if (!email || !password) {
        setError('Please enter both email and password');
        return;
      }
      const result = await signup(email, password);
      if (result.success) {
        setSuccess('Account created! Please check your email to verify your account, or try logging in.');
        
        // Try to login immediately just in case verification is off
        const loginSuccess = await login(email, password);
        if (loginSuccess) {
             navigate('/');
        }
      } else {
        setError(result.error || 'Failed to sign up');
      }
    } else if (mode === 'password') {
      // Support legacy "admin123" input in the password field if email is empty
      if (!email && password === 'admin123') {
          if (await login('admin123')) {
              navigate('/');
              return;
          }
      }

      if (await login(email, password)) {
        navigate('/');
      } else {
        setError('Invalid email or password');
      }
    } else if (mode === 'forgot-password') {
      if (!email) {
        setError('Please enter your email');
        return;
      }
      const sent = await resetPassword(email);
      if (sent) {
        setSuccess('Password reset link sent! Check your email.');
      } else {
        setError('Failed to send reset link. Please try again.');
      }
    } else {
      // Magic Link
      if (!email) {
        setError('Please enter your email');
        return;
      }
      const sent = await loginWithMagicLink(email);
      if (sent) {
        setSuccess('Check your email for the login link!');
      } else {
        setError('Failed to send magic link. Please try again.');
      }
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-[70vh] px-4">
      <div className="w-full max-w-sm rounded-[28px] bg-primary p-1 shadow-[0_24px_60px_-30px_rgba(0,0,0,0.65)]">
        <div className="bg-white p-8 rounded-[24px] border border-black/5">
        <div className="flex flex-col items-center mb-6">
          <div className="w-16 h-16 bg-accent rounded-full flex items-center justify-center mb-4 text-black shadow-[0_10px_20px_-12px_rgba(0,0,0,0.5)]">
            <Lock className="w-8 h-8" />
          </div>
          <div className="brand-kicker mb-3">Cort Club</div>
          <h1 className="text-2xl font-black text-slate-950">Access cørtapp</h1>
          <p className="text-slate-500 text-center mt-2">
            Enter your credentials to manage the league
          </p>
        </div>

        {/* Mode Toggle */}
        <div className="flex bg-slate-100 p-1 rounded-2xl mb-6">
          <button
            type="button"
            onClick={() => { setMode('password'); setError(''); setSuccess(''); }}
            className={`flex-1 py-2 text-sm font-bold rounded-lg transition-all ${
              mode === 'password' 
                ? 'bg-primary text-white shadow-sm' 
                : 'text-slate-500 hover:text-slate-700'
            }`}
          >
            Password
          </button>
          <button
            type="button"
            onClick={() => { setMode('magic-link'); setError(''); setSuccess(''); }}
            className={`flex-1 py-2 text-sm font-bold rounded-lg transition-all ${
              mode === 'magic-link' 
                ? 'bg-primary text-white shadow-sm' 
                : 'text-slate-500 hover:text-slate-700'
            }`}
          >
            Magic Link
          </button>
          <button
            type="button"
            onClick={() => { setMode('signup'); setError(''); setSuccess(''); }}
            className={`flex-1 py-2 text-sm font-bold rounded-lg transition-all ${
              mode === 'signup' 
                ? 'bg-primary text-white shadow-sm' 
                : 'text-slate-500 hover:text-slate-700'
            }`}
          >
            Sign Up
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="text-xs font-bold text-slate-500 uppercase ml-1">Email</label>
            <div className="relative">
                <Mail className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
                <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="w-full pl-10 p-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-primary focus:border-transparent outline-none font-medium"
                autoFocus
                />
            </div>
          </div>

          {mode === 'password' && (
            <div>
              <label className="text-xs font-bold text-slate-500 uppercase ml-1">Password</label>
              <div className="relative">
                  <Lock className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
                  <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-10 p-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-primary focus:border-transparent outline-none font-medium"
                  />
              </div>
              <div className="flex justify-end mt-1">
                <button
                  type="button"
                  onClick={() => { setMode('forgot-password'); setError(''); setSuccess(''); }}
                  className="text-xs text-primary font-bold hover:underline"
                >
                  Forgot Password?
                </button>
              </div>
            </div>
          )}
          
          {mode === 'signup' && (
            <div>
              <label className="text-xs font-bold text-slate-500 uppercase ml-1">Create Password</label>
              <div className="relative">
                  <Lock className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
                  <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-10 p-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-primary focus:border-transparent outline-none font-medium"
                  />
              </div>
            </div>
          )}
          
          {mode === 'forgot-password' && (
             <div className="text-sm text-slate-500 bg-slate-50 p-3 rounded-lg border border-slate-200">
                Enter your email address and we'll send you a link to reset your password.
             </div>
          )}

          {error && (
            <div className="p-3 bg-red-50 text-red-600 text-sm rounded-xl font-medium">
              {error}
            </div>
          )}
          
          {success && (
            <div className="p-3 bg-green-50 text-green-600 text-sm rounded-xl font-medium">
              {success}
            </div>
          )}

          <button
            type="submit"
            disabled={mode === 'signup' ? (!email || !password) : !email}
            className="w-full bg-accent text-black py-3 rounded-xl font-black hover:bg-[#f4dc00] transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {mode === 'password' ? 'Login' : 
             mode === 'signup' ? 'Create Account' : 
             mode === 'forgot-password' ? 'Send Reset Link' : 
             (
               <>
                 <Wand2 className="w-4 h-4" />
                 Send Magic Link
               </>
             )}
          </button>
          
          {mode === 'forgot-password' && (
            <button
                type="button"
                onClick={() => { setMode('password'); setError(''); setSuccess(''); }}
                className="w-full text-slate-500 text-sm font-bold hover:text-slate-800 mt-2"
            >
                Back to Login
            </button>
          )}
        </form>
        </div>
      </div>
    </div>
  );
}
