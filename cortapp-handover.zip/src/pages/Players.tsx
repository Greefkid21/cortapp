import { useEffect, useRef, useState } from 'react';
import { Player } from '../types';
import { User, Edit2, Plus, Upload, X, Save, Trash2, Check, HelpCircle } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useAvailability } from '../context/AvailabilityContext';
import { useSeason } from '../context/SeasonContext';
import { getNextWeekStartDate } from '../lib/utils';
import { Link } from 'react-router-dom';

interface PlayersPageProps {
  players: Player[];
  onAddPlayer: (name: string, avatar?: string, email?: string, seed?: number, division?: number, inLeague?: boolean) => Promise<void>;
  onUpdatePlayer: (id: string, name: string, avatar?: string, seed?: number, division?: number, inLeague?: boolean) => Promise<void>;
  onDeletePlayer: (id: string) => Promise<void>;
}

export function PlayersPage({ players, onAddPlayer, onUpdatePlayer, onDeletePlayer }: PlayersPageProps) {
  const { isAdmin } = useAuth();
  const { getAvailability } = useAvailability();
  const { currentSeasonDivisionCount } = useSeason();
  const nextWeekStart = getNextWeekStartDate();
  const [isEditing, setIsEditing] = useState<string | null>(null); // 'new' or player ID
  const [editName, setEditName] = useState('');
  const [editEmail, setEditEmail] = useState('');
  const [editSeed, setEditSeed] = useState<number | undefined>(undefined);
  const [editDivision, setEditDivision] = useState<number>(1);
  const [editInLeague, setEditInLeague] = useState<boolean>(true);
  const [editAvatar, setEditAvatar] = useState<string | undefined>(undefined);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const availableDivisions = Array.from({ length: currentSeasonDivisionCount }, (_, i) => i + 1);

  useEffect(() => {
    if (editInLeague && editDivision > currentSeasonDivisionCount) {
      setEditDivision(1);
    }
  }, [editDivision, editInLeague, currentSeasonDivisionCount]);

  const startNew = () => {
    setEditName('');
    setEditEmail('');
    setEditSeed(undefined);
    setEditDivision(1);
    setEditInLeague(true);
    setEditAvatar(undefined);
    setIsEditing('new');
  };

  const startEdit = (player: Player) => {
    setEditName(player.name);
    setEditEmail(''); // Don't allow editing email for existing players here yet
    setEditSeed(player.seed);
    setEditDivision(Math.min(player.division || 1, currentSeasonDivisionCount));
    setEditInLeague(player.in_league !== false);
    setEditAvatar(player.avatar);
    setIsEditing(player.id);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setEditAvatar(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editName.trim() || isSubmitting) return;

    setIsSubmitting(true);
    try {
      if (isEditing === 'new') {
        await onAddPlayer(editName, editAvatar, editEmail, editSeed, editDivision, editInLeague);
      } else if (isEditing) {
        await onUpdatePlayer(isEditing, editName, editAvatar, editSeed, editDivision, editInLeague);
      }
      setIsEditing(null);
    } catch (error) {
      console.error('Error saving player:', error);
      // Alert is handled in App.tsx
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6 pb-20">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-slate-900">Players</h2>
        {isAdmin && (
        <button
          onClick={startNew}
          className="bg-primary text-white px-4 py-2 rounded-xl font-bold flex items-center gap-2 shadow-lg shadow-primary/20 hover:bg-teal-700 transition-colors"
        >
          <Plus className="w-5 h-5" /> Add Player
        </button>
        )}
      </div>

      {/* Edit/Add Form Modal/Overlay */}
      {isEditing && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-md p-6 shadow-xl animate-in fade-in zoom-in-95">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-bold text-slate-800">
                {isEditing === 'new' ? 'Add New Player' : 'Edit Player'}
              </h3>
              <button onClick={() => setIsEditing(null)} className="text-slate-400 hover:text-slate-600">
                <X className="w-6 h-6" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Avatar Upload */}
              <div className="flex flex-col items-center gap-4">
                <div 
                  className="w-24 h-24 rounded-full bg-slate-100 border-2 border-dashed border-slate-300 flex items-center justify-center overflow-hidden cursor-pointer hover:border-primary transition-colors relative group"
                  onClick={() => fileInputRef.current?.click()}
                >
                  {editAvatar ? (
                    <img src={editAvatar} alt="Preview" className="w-full h-full object-cover" />
                  ) : (
                    <User className="w-10 h-10 text-slate-300" />
                  )}
                  <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <Upload className="w-6 h-6 text-white" />
                  </div>
                </div>
                <input 
                  ref={fileInputRef}
                  type="file" 
                  accept="image/*" 
                  className="hidden" 
                  onChange={handleImageUpload}
                />
                <button 
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="text-sm text-primary font-medium hover:underline"
                >
                  {editAvatar ? 'Change Photo' : 'Upload Photo'}
                </button>
              </div>

              {/* Name Input */}
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700">Name</label>
                <input
                  type="text"
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  placeholder="Player Name"
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-primary outline-none transition-all font-medium"
                  autoFocus
                />
              </div>

              {/* Seed Input */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700">Seed</label>
                  <input
                    type="number"
                    value={editSeed || ''}
                    onChange={(e) => setEditSeed(e.target.value ? parseInt(e.target.value) : undefined)}
                    placeholder="e.g. 1"
                    min="1"
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-primary outline-none transition-all font-medium"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700">League</label>
                  <select
                    value={editInLeague ? String(editDivision) : 'none'}
                    onChange={(e) => {
                      const v = e.target.value;
                      if (v === 'none') {
                        setEditInLeague(false);
                      } else {
                        setEditInLeague(true);
                        setEditDivision(parseInt(v));
                      }
                    }}
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-primary outline-none transition-all font-medium"
                  >
                    {availableDivisions.map((division) => (
                      <option key={division} value={division}>
                        Division {division}
                      </option>
                    ))}
                    <option value="none">No League</option>
                  </select>
                </div>
              </div>
              <p className="text-xs text-slate-500">
                Seed 1 is strongest. “No League” excludes the player from the league table and next season fixtures.
              </p>

              {/* Email Input (New Player Only) */}
              {isEditing === 'new' && (
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700">Email (Optional - Sends Invite)</label>
                  <input
                    type="email"
                    value={editEmail}
                    onChange={(e) => setEditEmail(e.target.value)}
                    placeholder="player@example.com"
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-primary outline-none transition-all font-medium"
                  />
                  <p className="text-xs text-slate-500">
                    If provided, this player will receive an email to join the league and manage their profile.
                  </p>
                </div>
              )}

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsEditing(null)}
                  className="flex-1 py-3 text-slate-600 font-bold bg-slate-100 rounded-xl hover:bg-slate-200 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-3 text-white font-bold bg-primary rounded-xl hover:bg-teal-700 transition-colors flex items-center justify-center gap-2"
                >
                  <Save className="w-5 h-5" /> Save
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Players List */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {players.map((player) => (
          <div key={player.id} className="bg-white p-4 rounded-xl shadow-sm border border-slate-100 flex items-center justify-between group hover:border-primary/30 transition-colors">
            <Link to={`/player/${player.id}`} className="flex items-center gap-4 flex-1 hover:opacity-80 transition-opacity">
              <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center overflow-hidden border border-slate-100">
                {player.avatar ? (
                  <img src={player.avatar} alt={player.name} className="w-full h-full object-cover" />
                ) : (
                  <span className="font-bold text-slate-400 text-lg">
                    {player.name.split(' ').map(n => n[0]).join('').slice(0, 2)}
                  </span>
                )}
              </div>
              <div>
                <h3 className="font-bold text-slate-900 group-hover:text-primary transition-colors">{player.name}</h3>
                <div className="flex items-center gap-2 mb-1">
                  <p className="text-xs text-slate-500">{player.stats.matchesPlayed} matches played</p>
                  {player.in_league === false ? (
                    <span className="text-[10px] bg-red-50 text-red-600 px-1.5 py-0.5 rounded font-bold">No League</span>
                  ) : (
                    <span className="text-[10px] bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded font-bold">Div {player.division || 1}</span>
                  )}
                </div>
                {/* Availability Info */}
                <div className="flex items-center gap-2 text-xs">
                  {(() => {
                    const avail = getAvailability(player.id, nextWeekStart);
                    if (!avail) return <span className="text-slate-400 flex items-center gap-1"><HelpCircle className="w-3 h-3" /> No info</span>;
                    if (!avail.isAvailable) return <span className="text-red-500 flex items-center gap-1"><X className="w-3 h-3" /> Unavailable</span>;
                    return (
                      <span className="text-green-600 flex items-center gap-1">
                        <Check className="w-3 h-3" /> 
                        {avail.daysAvailable.length > 0 ? avail.daysAvailable.join(', ') : 'Available'}
                      </span>
                    );
                  })()}
                </div>
              </div>
            </Link>
            {isAdmin && (
            <div className="flex gap-1">
                <button 
                  onClick={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      startEdit(player);
                  }}
                  className="p-2 text-slate-400 hover:text-primary hover:bg-slate-50 rounded-lg transition-colors z-10"
                  title="Edit Player"
                >
                  <Edit2 className="w-5 h-5" />
                </button>
                <button 
                  onClick={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      onDeletePlayer(player.id);
                  }}
                  className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors z-10"
                  title="Delete Player"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
            </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
