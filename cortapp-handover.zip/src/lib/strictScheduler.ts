import { Player, Match } from '../types';

// ---------------------------------------------------------------------------
// TYPES
// ---------------------------------------------------------------------------

export interface StrictModeStats {
  maxOpponentRepeat: number;
  minOpponentRepeat: number;
  opponentCountHistogram: Record<string, number>; // "0":x, "1":y, ...
  cost: number;
  total_3x_pairs: number;
  seededFairnessWarning?: boolean; // Deprecated by seededFairnessForcedFailure but kept for compatibility
  seededFairnessForcedFailure?: boolean; // New flag for strict 50% rule violation
  count_3x_by_tier: {
    AA: number;
    AB: number;
    AC: number;
    BB: number;
    BC: number;
    CC: number;
  };
  seeded_3x_summary: { // Keep for backward compatibility if needed, or map to new structure
    total: number;
    topTop: number;
    topMid: number;
    midMid: number;
    midLow: number;
    lowLow: number;
    topLow: number;
  };
  per_player_strength_of_schedule: Array<{
    id: string;
    seed: number;
    avg_opponent_seed: number;
    matches_vs_top_quartile: number;
    matches_vs_bottom_quartile: number;
  }>;
}

export interface StrictModeResult {
  ok: boolean;
  fixtures?: Match[][];
  stats?: StrictModeStats;
  explanation?: string;
  error?: {
    code: string;
    message: string;
  };
}

// ---------------------------------------------------------------------------
// HELPER: SEED UTILS
// ---------------------------------------------------------------------------

function getSeedMetrics(players: Player[]) {
  const pSeeds = players.map((p, idx) => (p.seed ?? (idx + 1)));
  const maxSeed = Math.max(...pSeeds, 1);
  const minSeed = Math.min(...pSeeds, 1);

  // Normalization functions
  // seedNorm(i): 1.0 = strongest (seed 1), 0.0 = weakest (maxSeed)
  const seedNorm = (idx: number) => {
    if (maxSeed === minSeed) return 0.5;
    return (maxSeed - pSeeds[idx]) / (maxSeed - minSeed);
  };

  // Tier helper (1=A, 2=B, 3=C)
  const getTier = (idx: number): 1 | 2 | 3 => {
    const seed = pSeeds[idx];
    if (seed <= 4) return 1; // Tier A
    if (seed <= 8) return 2; // Tier B
    return 3;                // Tier C (9+)
  };

  return { maxSeed, minSeed, pSeeds, seedNorm, getTier };
}

// ---------------------------------------------------------------------------
// CORE SCHEDULER
// ---------------------------------------------------------------------------

export function generateStrictSchedule(
  players: Player[], 
  startDate: string, // Unused logic-wise but kept for signature compatibility if needed
  maxTimeMs: number = 20000 // Increased default time to improve strict constraint success (especially multi-division)
): StrictModeResult {
  // If players have divisions, we generate schedules per division and combine them
  const divisions = Array.from(new Set(players.map(p => p.division || 1))).sort();
  
  if (divisions.length > 1) {
    const allFixtures: Match[][] = [];
    const allStats: any[] = [];
    let allOk = true;
    let combinedExplanation = "";

    for (const div of divisions) {
      const divPlayers = players.filter(p => (p.division || 1) === div);
      if (divPlayers.length === 0) continue;
      
      const result = generateStrictSchedule(divPlayers, startDate, maxTimeMs / divisions.length);
      if (!result.ok) {
        allOk = false;
        return {
          ok: false,
          error: {
            code: result.error?.code || "DIVISION_GEN_FAILED",
            message: `Division ${div} failed: ${result.error?.message}`
          }
        };
      }
      
      // Combine fixtures by week
      result.fixtures?.forEach((weekMatches, weekIdx) => {
        if (!allFixtures[weekIdx]) allFixtures[weekIdx] = [];
        allFixtures[weekIdx].push(...weekMatches);
      });
      
      if (result.stats) allStats.push(result.stats);
      combinedExplanation += `Division ${div}: ${result.explanation}\n`;
    }

    return {
      ok: allOk,
      fixtures: allFixtures,
      explanation: combinedExplanation,
      // Note: stats are simplified for multi-division for now
      stats: allStats[0] 
    };
  }

  const N = players.length;
  const startTime = Date.now();
  const maxOpponentRepeatAllowed = N === 8 ? 4 : 3;

  // 1. ELIGIBILITY CHECKS
  if (N % 4 !== 0) {
    return {
      ok: false,
      error: {
        code: "STRICT_MODE_REQUIRES_N_DIV_4",
        message: `Strict mode requires N divisible by 4 (e.g., 12, 16, 20). You provided ${N}.`
      }
    };
  }

  // 2. PREPARE DATA
  const { pSeeds, seedNorm, getTier } = getSeedMetrics(players);

  // Config
  // Costs are tuned to strongly prefer opponent balance, but we now allow best-effort schedules
  // even when perfect opponent coverage (no 0s) is not achievable for a given division.
  const COST_GAP = 1000;
  const COST_VIOLATION = 50000000; // 50M
  const COST_SEED_MATCH_BALANCE = 2500;

  const teamStrength = (pair: [number, number]) => seedNorm(pair[0]) + seedNorm(pair[1]);
  const matchSeedBalanceCost = (a: [number, number], b: [number, number]) => {
    const diff = teamStrength(a) - teamStrength(b);
    return diff * diff;
  };

  // Cost Function
  const getPairCost = (_i: number, _j: number, count: number): number => {
      // Hard penalties based on counts - HUGE MAGNITUDE to enforce strict constraints
      if (count === 2) return 0; // Ideal
      if (count === 1 || count === 3) return COST_GAP;
      if (count === 0) return COST_VIOLATION;
      // count >= 4
      if (maxOpponentRepeatAllowed >= 4 && count === 4) return COST_VIOLATION * 2;
      return COST_VIOLATION + (count - 3) * COST_VIOLATION; 
  };

  // 3. CONSTRUCTION (Partner-Perfect Wheel)
  // Polygon method for 1-factorization of K_N
  const numRounds = N - 1;
  const matchesPerWeek = N / 4;

  const shuffle = <T,>(arr: T[]): T[] => {
    const a = [...arr];
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
  };

  const buildRoundsFromCircle = (circle: number[]) => {
    const ring = circle.slice(0, N - 1);
    const fixedPoint = circle[N - 1];
    const rounds: Array<Array<[number, number]>> = [];

    for (let r = 0; r < numRounds; r++) {
      const roundPairs: [number, number][] = [];
      roundPairs.push([ring[0], fixedPoint]);

      for (let k = 1; k <= (N - 2) / 2; k++) {
        const p1 = ring[k];
        const p2 = ring[ring.length - k];
        roundPairs.push([p1, p2]);
      }

      rounds.push(roundPairs);

      const last = ring.pop()!;
      ring.unshift(last);
    }

    return rounds;
  };

  // 4. OPTIMIZATION (Hill Climbing with Random Restarts)
  
  const calculateTotalCostFromCounts = (counts: number[][]) => {
    let cost = 0;
    for (let i = 0; i < N; i++) {
      for (let j = i + 1; j < N; j++) {
        cost += getPairCost(i, j, counts[i][j]);
      }
    }
    return cost;
  };

  const calculateTotalScheduleSeedCost = (sched: [number, number][][][]) => {
    let cost = 0;
    for (const week of sched) {
      for (const match of week) {
        cost += matchSeedBalanceCost(match[0], match[1]);
      }
    }
    return cost * COST_SEED_MATCH_BALANCE;
  };

  // Best Schedules Hierarchy
  let globalBestSchedule: [number, number][][][] | null = null;
  let globalBestCost = Infinity;

  // Level 1: Hard Constraints Met (1 <= count <= 3)
  let hardValidBestSchedule: [number, number][][][] | null = null;
  let hardValidBestCost = Infinity;

  // Level 2: Hard + Soft Fairness Met (A-C <= A-A)
  let validBestSchedule: [number, number][][][] | null = null;
  let validBestCost = Infinity;

  const isValidFairness = (_countsMatrix: number[][]): boolean => true;

  // Validation Helper for Hard Constraints
  const isValidHard = (countsMatrix: number[][]): boolean => {
    for (let i = 0; i < N; i++) {
      for (let j = i + 1; j < N; j++) {
        const c = countsMatrix[i][j];
        if (c > maxOpponentRepeatAllowed) return false;
      }
    }
    return true;
  };

  // Initial cost check
  const opponentCounts = Array(N).fill(0).map(() => Array(N).fill(0));
  const updateCounts = (sched: [number, number][][][], op: 'add' | 'sub', countsMatrix: number[][]) => {
      const val = op === 'add' ? 1 : -1;
      for (const week of sched) {
        for (const match of week) {
          const t1 = match[0];
          const t2 = match[1];
          // Opponents are t1 vs t2
          // t1[0] vs t2[0], t1[0] vs t2[1], t1[1] vs t2[0], t1[1] vs t2[1]
          countsMatrix[t1[0]][t2[0]] += val; countsMatrix[t2[0]][t1[0]] += val;
          countsMatrix[t1[0]][t2[1]] += val; countsMatrix[t2[1]][t1[0]] += val;
          countsMatrix[t1[1]][t2[0]] += val; countsMatrix[t2[0]][t1[1]] += val;
          countsMatrix[t1[1]][t2[1]] += val; countsMatrix[t2[1]][t1[1]] += val;
        }
      }
  };

  if (N === 8) {
    const shuffle = <T,>(arr: T[]): T[] => {
      const a = [...arr];
      for (let i = a.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [a[i], a[j]] = [a[j], a[i]];
      }
      return a;
    };

    const buildRoundsFromCircle = (circle: number[]) => {
      const ring = circle.slice(0, N - 1);
      const fixedPoint = circle[N - 1];
      const rounds: Array<Array<[number, number]>> = [];

      for (let r = 0; r < numRounds; r++) {
        const roundPairs: [number, number][] = [];
        roundPairs.push([ring[0], fixedPoint]);

        for (let k = 1; k <= (N - 2) / 2; k++) {
          const p1 = ring[k];
          const p2 = ring[ring.length - k];
          roundPairs.push([p1, p2]);
        }

        rounds.push(roundPairs);

        const last = ring.pop()!;
        ring.unshift(last);
      }

      return rounds;
    };

    const pairings = [
      [[0, 1], [2, 3]],
      [[0, 2], [1, 3]],
      [[0, 3], [1, 2]],
    ] as const;

    const addOpponents = (pairA: [number, number], pairB: [number, number], delta: number, counts: number[][]) => {
      const [a1, a2] = pairA;
      const [b1, b2] = pairB;
      counts[a1][b1] += delta; counts[b1][a1] += delta;
      counts[a1][b2] += delta; counts[b2][a1] += delta;
      counts[a2][b1] += delta; counts[b1][a2] += delta;
      counts[a2][b2] += delta; counts[b2][a2] += delta;
    };

    const scoreCounts = (counts: number[][]) => {
      let zeros = 0;
      let fours = 0;
      let max = 0;
      let variance = 0;
      for (let i = 0; i < N; i++) {
        for (let j = i + 1; j < N; j++) {
          const c = counts[i][j];
          if (c === 0) zeros++;
          if (c === 4) fours++;
          max = Math.max(max, c);
          const diff = c - 2;
          variance += diff * diff;
        }
      }
      return { zeros, fours, max, variance };
    };

    let bestSchedule: [number, number][][][] | null = null;
    let bestMax = Infinity;
    let bestFours = Infinity;
    let bestZeros = Infinity;
    let bestSeedCost = Infinity;
    let bestVariance = Infinity;

    const circleAttempts = 40;
    for (let circleAttempt = 0; circleAttempt < circleAttempts; circleAttempt++) {
      if ((Date.now() - startTime) >= maxTimeMs) break;

      const circle = shuffle(Array.from({ length: N }, (_, i) => i));
      const rounds = buildRoundsFromCircle(circle);
      const counts = Array(N).fill(0).map(() => Array(N).fill(0));
      const schedule: [number, number][][][] = [];

      const dfs = (roundIdx: number) => {
        if ((Date.now() - startTime) >= maxTimeMs) return;

        if (roundIdx === numRounds) {
          const s = scoreCounts(counts);
          if (s.max > maxOpponentRepeatAllowed) return;
          const seedCost = calculateTotalScheduleSeedCost(schedule);
          if (
            s.max < bestMax ||
            (s.max === bestMax && s.fours < bestFours) ||
            (s.max === bestMax && s.fours === bestFours && s.zeros < bestZeros) ||
            (s.max === bestMax && s.fours === bestFours && s.zeros === bestZeros && seedCost < bestSeedCost) ||
            (s.max === bestMax && s.fours === bestFours && s.zeros === bestZeros && seedCost === bestSeedCost && s.variance < bestVariance)
          ) {
            bestMax = s.max;
            bestFours = s.fours;
            bestZeros = s.zeros;
            bestSeedCost = seedCost;
            bestVariance = s.variance;
            bestSchedule = JSON.parse(JSON.stringify(schedule));
          }
          return;
        }

        const weekPairs = rounds[roundIdx];

        for (const opt of pairings) {
          const weekMatches: [number, number][][] = [];

          const pA0 = weekPairs[opt[0][0]];
          const pA1 = weekPairs[opt[0][1]];
          const pB0 = weekPairs[opt[1][0]];
          const pB1 = weekPairs[opt[1][1]];

          addOpponents(pA0, pA1, 1, counts);
          if (!isValidHard(counts)) {
            addOpponents(pA0, pA1, -1, counts);
            continue;
          }
          addOpponents(pB0, pB1, 1, counts);
          if (!isValidHard(counts)) {
            addOpponents(pB0, pB1, -1, counts);
            addOpponents(pA0, pA1, -1, counts);
            continue;
          }

          weekMatches.push([pA0, pA1], [pB0, pB1]);
          schedule.push(weekMatches);

          dfs(roundIdx + 1);

          schedule.pop();
          addOpponents(pB0, pB1, -1, counts);
          addOpponents(pA0, pA1, -1, counts);
        }
      };

      dfs(0);

      if (bestSchedule && bestMax <= 4 && bestFours <= 2 && bestZeros <= 1) break;
    }

    if (bestSchedule) {
      hardValidBestSchedule = bestSchedule;
      hardValidBestCost = bestVariance + (bestSeedCost / COST_SEED_MATCH_BALANCE);
      validBestSchedule = bestSchedule;
      validBestCost = bestVariance + (bestSeedCost / COST_SEED_MATCH_BALANCE);
      globalBestSchedule = bestSchedule;
      globalBestCost = bestVariance + (bestSeedCost / COST_SEED_MATCH_BALANCE);
    }
  }
  
  // Optimization Loop with Retries
  const MAX_RETRIES = 30;
  let attempt = 0;

  while (attempt < MAX_RETRIES && !validBestSchedule) {
    attempt++;
    // If we have a hard valid schedule, we can be a bit less desperate, 
    // but we really want strict fairness.
    // If we are out of time, we stop.
    if ((Date.now() - startTime) >= maxTimeMs) break;

    // 4a. Random Initial State
    // Important: randomize the underlying 1-factorization by permuting the circle order.
    // This dramatically improves solvability for N=8/12/etc.
    const circle = shuffle(Array.from({ length: N }, (_, i) => i));
    const rounds = buildRoundsFromCircle(circle);

    // Shuffle pair order within each week before grouping into matches
    const currentSchedule = rounds.map(weekPairs => {
      const shuffledPairs = shuffle(weekPairs);
      const matches: [number, number][][] = [];
      for (let i = 0; i < shuffledPairs.length; i += 2) {
        matches.push([shuffledPairs[i], shuffledPairs[i + 1]]);
      }
      return matches;
    });

    const currentCounts = Array(N).fill(0).map(() => Array(N).fill(0));
    updateCounts(currentSchedule, 'add', currentCounts);
    let currentCost = calculateTotalCostFromCounts(currentCounts) + calculateTotalScheduleSeedCost(currentSchedule);

    if (!globalBestSchedule || currentCost < globalBestCost) {
      globalBestCost = currentCost;
      globalBestSchedule = JSON.parse(JSON.stringify(currentSchedule));
    }

    // 4b. Local Search
    let localIter = 0;
    const maxLocalIter = 60000;

    while (localIter < maxLocalIter && (Date.now() - startTime) < maxTimeMs) {
        localIter++;

        // Sync counts periodically to prevent drift (especially for small N where it's cheap)
        if (N <= 20 || localIter % 100 === 0) {
             // Reset and recompute
             for(let i=0; i<N; i++) for(let j=0; j<N; j++) currentCounts[i][j] = 0;
             updateCounts(currentSchedule, 'add', currentCounts);
             currentCost = calculateTotalCostFromCounts(currentCounts) + calculateTotalScheduleSeedCost(currentSchedule);
        }

        // Pick a random week
        const w = Math.floor(Math.random() * numRounds);
        const week = currentSchedule[w];
        if (matchesPerWeek < 2) break;

        // Try multiple random swaps per iteration
        for(let k=0; k<20; k++) { // Increased swap attempts
            const m1Idx = Math.floor(Math.random() * matchesPerWeek);
            let m2Idx = Math.floor(Math.random() * matchesPerWeek);
            while (m2Idx === m1Idx) m2Idx = Math.floor(Math.random() * matchesPerWeek);
            
            const match1 = week[m1Idx];
            const match2 = week[m2Idx];

            // Pick random slots to swap (0 or 1)
            const slot1 = Math.random() < 0.5 ? 0 : 1;
            const slot2 = Math.random() < 0.5 ? 0 : 1;

            const t1_stay = match1[1 - slot1];
            const t1_move = match1[slot1];
            const t2_stay = match2[1 - slot2];
            const t2_move = match2[slot2];

            // Helper to calc delta cost for swapping t1_move and t2_move
            const getMatchDelta = () => {
                let delta = 0;
                
                // Remove current: (t1_stay vs t1_move) and (t2_stay vs t2_move)
                // Add new: (t1_stay vs t2_move) and (t2_stay vs t1_move)
                
                // For match1 (removing)
                const pairsRemove1 = [[t1_stay[0], t1_move[0]], [t1_stay[0], t1_move[1]], [t1_stay[1], t1_move[0]], [t1_stay[1], t1_move[1]]];
                for (const [p1, p2] of pairsRemove1) {
                    const c = currentCounts[p1][p2];
                    delta -= getPairCost(p1, p2, c);
                    delta += getPairCost(p1, p2, c - 1);
                }

                // For match2 (removing)
                const pairsRemove2 = [[t2_stay[0], t2_move[0]], [t2_stay[0], t2_move[1]], [t2_stay[1], t2_move[0]], [t2_stay[1], t2_move[1]]];
                for (const [p1, p2] of pairsRemove2) {
                    const c = currentCounts[p1][p2];
                    delta -= getPairCost(p1, p2, c);
                    delta += getPairCost(p1, p2, c - 1);
                }

                // For match1 (adding t2_move)
                const pairsAdd1 = [[t1_stay[0], t2_move[0]], [t1_stay[0], t2_move[1]], [t1_stay[1], t2_move[0]], [t1_stay[1], t2_move[1]]];
                for (const [p1, p2] of pairsAdd1) {
                    const c = currentCounts[p1][p2];
                    delta -= getPairCost(p1, p2, c);
                    delta += getPairCost(p1, p2, c + 1);
                }

                // For match2 (adding t1_move)
                const pairsAdd2 = [[t2_stay[0], t1_move[0]], [t2_stay[0], t1_move[1]], [t2_stay[1], t1_move[0]], [t2_stay[1], t1_move[1]]];
                for (const [p1, p2] of pairsAdd2) {
                    const c = currentCounts[p1][p2];
                    delta -= getPairCost(p1, p2, c);
                    delta += getPairCost(p1, p2, c + 1);
                }

                const oldSeed =
                  matchSeedBalanceCost(t1_stay, t1_move) +
                  matchSeedBalanceCost(t2_stay, t2_move);
                const newSeed =
                  matchSeedBalanceCost(t1_stay, t2_move) +
                  matchSeedBalanceCost(t2_stay, t1_move);
                delta += (newSeed - oldSeed) * COST_SEED_MATCH_BALANCE;
                
                return delta;
            };

            const delta = getMatchDelta();

            // Accept improvement OR Simulated Annealing
            // If delta < 0, we improve (cost goes down).
            // If delta > 0, we degrade.
            // SA Probability: exp(-delta / Temp). 
            // We use a simplified constant factor here.
            // Since penalties are huge (50000), we only want to accept bad moves if they are small (seed optimizations).
            // If delta is huge (e.g. creating a 0 or 4), prob should be 0.
            
            let accept = false;
            if (delta < 0) {
                accept = true;
            } else {
                 // Allow uphill moves if they are "small" (seed adjustments or breaking perfect 2s to fix others)
                 // 2->3 costs 1000. So we need threshold > 1000.
                 if (delta < 2000 && Math.random() < 0.05) {
                    accept = true;
                 }
            }

            if (accept) {
                // Apply move
                // Update counts
                const pairsRemove = [
                    ...[[t1_stay[0], t1_move[0]], [t1_stay[0], t1_move[1]], [t1_stay[1], t1_move[0]], [t1_stay[1], t1_move[1]]],
                    ...[[t2_stay[0], t2_move[0]], [t2_stay[0], t2_move[1]], [t2_stay[1], t2_move[0]], [t2_stay[1], t2_move[1]]]
                ];
                for(const [p1, p2] of pairsRemove) {
                    currentCounts[p1][p2]--; currentCounts[p2][p1]--;
                }
                
                const pairsAdd = [
                    ...[[t1_stay[0], t2_move[0]], [t1_stay[0], t2_move[1]], [t1_stay[1], t2_move[0]], [t1_stay[1], t2_move[1]]],
                    ...[[t2_stay[0], t1_move[0]], [t2_stay[0], t1_move[1]], [t2_stay[1], t1_move[0]], [t2_stay[1], t1_move[1]]]
                ];
                for(const [p1, p2] of pairsAdd) {
                    currentCounts[p1][p2]++; currentCounts[p2][p1]++;
                }

                // Swap in schedule
                match1[slot1] = t2_move;
                match2[slot2] = t1_move;
                
                currentCost += delta;
            }
        }
    }

    // Check validation if this is a candidate for valid best
    const isHardValid = isValidHard(currentCounts);
    
    if (isHardValid) {
        // Update Hard Valid Best
        if (currentCost < hardValidBestCost) {
             hardValidBestCost = currentCost;
             hardValidBestSchedule = JSON.parse(JSON.stringify(currentSchedule));
        }

        // Update Full Valid Best (Hard + Fairness)
        if (isValidFairness(currentCounts)) {
             if (currentCost < validBestCost) {
                validBestCost = currentCost;
                validBestSchedule = JSON.parse(JSON.stringify(currentSchedule));
             }
        }
    }
  }

  // Use Best Available Schedule
  // Priority: ValidBest (Hard+Fair) > HardValidBest (Hard) > GlobalBest
  if (!globalBestSchedule) {
    return {
      ok: false,
      error: {
        code: "SCHEDULER_INTERNAL_ERROR",
        message: "Failed to initialize scheduler state."
      }
    };
  }

  let schedule: [number, number][][][];
  if (validBestSchedule) {
      schedule = validBestSchedule;
      globalBestCost = validBestCost;
  } else if (hardValidBestSchedule) {
      schedule = hardValidBestSchedule;
      globalBestCost = hardValidBestCost;
  } else {
      schedule = globalBestSchedule;
  }
  
  // Recompute final counts for stats
  // Reset opponentCounts
  for(let i=0; i<N; i++) for(let j=0; j<N; j++) opponentCounts[i][j] = 0;
  updateCounts(schedule, 'add', opponentCounts);

  // 5. VALIDATION & STATS
  const stats: StrictModeStats = {
    maxOpponentRepeat: 0,
    minOpponentRepeat: 999,
    opponentCountHistogram: {},
    cost: globalBestCost,
    total_3x_pairs: 0,
    count_3x_by_tier: { AA: 0, AB: 0, AC: 0, BB: 0, BC: 0, CC: 0 },
    seeded_3x_summary: {
      total: 0,
      topTop: 0, topMid: 0, midMid: 0, midLow: 0, lowLow: 0, topLow: 0
    },
    per_player_strength_of_schedule: []
  };

  let valid = true;
  let validationError = "";

  // Check Fairness Floors
  for (let i = 0; i < N; i++) {
    for (let j = i + 1; j < N; j++) {
      const c = opponentCounts[i][j];
      stats.maxOpponentRepeat = Math.max(stats.maxOpponentRepeat, c);
      stats.minOpponentRepeat = Math.min(stats.minOpponentRepeat, c);
      
      const k = String(c);
      stats.opponentCountHistogram[k] = (stats.opponentCountHistogram[k] || 0) + 1;

      if (c > maxOpponentRepeatAllowed) {
        valid = false;
        validationError = `Opponent count violation: Player ${i+1} vs ${j+1} played ${c} times (must be 0-${maxOpponentRepeatAllowed}).`;
      }

      // Seed stats for 3x
      if (c === 3) {
        stats.seeded_3x_summary.total++;
        stats.total_3x_pairs++;
        
        // Tier Stats
        const t1 = getTier(i);
        const t2 = getTier(j);
        const tierCombo = [t1, t2].sort().join('');
        
        if (tierCombo === '11') stats.count_3x_by_tier.AA++;
        else if (tierCombo === '12') stats.count_3x_by_tier.AB++;
        else if (tierCombo === '13') stats.count_3x_by_tier.AC++;
        else if (tierCombo === '22') stats.count_3x_by_tier.BB++;
        else if (tierCombo === '23') stats.count_3x_by_tier.BC++;
        else if (tierCombo === '33') stats.count_3x_by_tier.CC++;

        // Legacy Stats (Approximate Quartiles)
        const s1 = seedNorm(i);
        const s2 = seedNorm(j);
        
        const q1 = s1 > 0.66 ? 'T' : (s1 < 0.33 ? 'L' : 'M');
        const q2 = s2 > 0.66 ? 'T' : (s2 < 0.33 ? 'L' : 'M');
        const combo = [q1, q2].sort().join('');
        
        if (combo === 'TT') stats.seeded_3x_summary.topTop++;
        else if (combo === 'TM') stats.seeded_3x_summary.topMid++;
        else if (combo === 'MM') stats.seeded_3x_summary.midMid++;
        else if (combo === 'LM') stats.seeded_3x_summary.midLow++;
        else if (combo === 'LL') stats.seeded_3x_summary.lowLow++;
        else if (combo === 'LT') stats.seeded_3x_summary.topLow++;
      }
    }
  }

  // Player Strength of Schedule
  stats.per_player_strength_of_schedule = players.map((p, idx) => {
    let oppSeedsSum = 0;
    let oppCount = 0;
    let vsTop = 0;
    let vsBot = 0;
    
    for (let oppIdx = 0; oppIdx < N; oppIdx++) {
      if (idx === oppIdx) continue;
      const cnt = opponentCounts[idx][oppIdx];
      if (cnt > 0) {
        oppSeedsSum += (pSeeds[oppIdx] * cnt);
        oppCount += cnt;
        if (seedNorm(oppIdx) > 0.66) vsTop += cnt;
        if (seedNorm(oppIdx) < 0.33) vsBot += cnt;
      }
    }
    
    return {
      id: p.id,
      seed: pSeeds[idx],
      avg_opponent_seed: oppCount > 0 ? parseFloat((oppSeedsSum / oppCount).toFixed(2)) : 0,
      matches_vs_top_quartile: vsTop,
      matches_vs_bottom_quartile: vsBot
    };
  });

  stats.seededFairnessForcedFailure = false;
  stats.seededFairnessWarning = false;
  
  if (!valid) {
    const failureExplanation = stats.seededFairnessForcedFailure 
      ? "Strict partner rotation and mathematical constraints prevented full seeded enforcement."
      : undefined;

    return {
      ok: false,
      error: {
        code: "FAIRNESS_VALIDATION_FAILED",
        message: validationError
      },
      stats, // Return stats even on failure for debugging
      explanation: failureExplanation
    };
  }

  // 6. FORMAT OUTPUT
  const fixtures: Match[][] = schedule.map((weekMatches, wIdx) => {
    // Calculate date for this week (wIdx * 7 days after start)
    const weekDate = new Date(startDate);
    weekDate.setDate(weekDate.getDate() + (wIdx * 7));
    const dateStr = weekDate.toISOString().split('T')[0]; // Keep as YYYY-MM-DD string

    return weekMatches.map((m, mIdx) => {
      // Map indices back to Player IDs
      return {
        id: `w${wIdx+1}-m${mIdx+1}`,
        team1: [players[m[0][0]].id, players[m[0][1]].id],
        team2: [players[m[1][0]].id, players[m[1][1]].id],
        round: wIdx + 1,
        date: dateStr, 
        court: mIdx + 1,
        sets: [],
        winner: null,
        status: 'scheduled'
      };
    });
  });

  // Explanation
  const avgSeed = stats.per_player_strength_of_schedule.reduce((acc, p) => acc + p.avg_opponent_seed, 0) / N;
  const hardSchedulePlayers = stats.per_player_strength_of_schedule
    .filter(p => p.avg_opponent_seed < avgSeed - 1.0) // Lower avg seed = Harder opponents
    .map(p => p.id);
  const easySchedulePlayers = stats.per_player_strength_of_schedule
    .filter(p => p.avg_opponent_seed > avgSeed + 1.0) // Higher avg seed = Easier opponents
    .map(p => p.id);

  let explanation = `
Generated strict mode schedule for ${N} players.
- Constraints: All hard constraints met (Partner rotation, No byes).
- Fairness: Opponent repeats bounded between ${stats.minOpponentRepeat} and ${stats.maxOpponentRepeat}.
- Seed Logic: 3x repeats biased by Tier (A=1-4, B=5-8, C=9-12).
  (AA: ${stats.count_3x_by_tier.AA}, AC: ${stats.count_3x_by_tier.AC}, CC: ${stats.count_3x_by_tier.CC}).
`.trim();

  if (hardSchedulePlayers.length > 0) {
      explanation += `\n- Note: Players ${hardSchedulePlayers.join(', ')} have a harder than average schedule.`;
  }
  if (easySchedulePlayers.length > 0) {
      explanation += `\n- Note: Players ${easySchedulePlayers.join(', ')} have an easier than average schedule.`;
  }

  if (stats.seededFairnessForcedFailure) {
      explanation += `\n- WARNING: Strict partner rotation and mathematical constraints prevented full seeded enforcement.`;
  }

  return {
    ok: true,
    fixtures,
    stats,
    explanation
  };
}
 
